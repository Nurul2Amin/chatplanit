package com.rayhan.plan_it;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
